@echo off
setlocal enabledelayedexpansion

:: ============================================================================
:: Distributed AI Cluster Kit - Standalone Worker Health Checker
:: Probes all configured worker nodes on TCP port 50052 with a 2-second timeout
:: Rule: Pure ASCII English, CRLF line endings, no pipelining
:: ============================================================================

:: ----------------------------------------------------------------------------
:: [EDIT THIS SECTION ONLY]
:: Enter worker IP addresses separated by spaces
:: ----------------------------------------------------------------------------
set "WORKER_IPS=192.168.0.11 192.168.0.12"
set "WORKER_PORT=50052"
:: ----------------------------------------------------------------------------

title Distributed AI Cluster - Worker Health Checker
echo ============================================================================
echo   Distributed AI Cluster Kit: Worker Nodes Health Status Check
echo ============================================================================
echo.
echo Target Port: %WORKER_PORT%
echo Timeout    : 2000 ms (2 seconds)
echo.

set /a UP_COUNT=0
set /a DOWN_COUNT=0
set /a TOTAL_COUNT=0

for %%W in (%WORKER_IPS%) do (
    set /a TOTAL_COUNT+=1
    set "IP=%%W"
    
    :: Probe TCP port using PowerShell with 2s timeout
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$c=New-Object Net.Sockets.TcpClient;$a=$c.BeginConnect('%%W',%WORKER_PORT%,$null,$null);$w=$a.AsyncWaitHandle.WaitOne(2000,$false);if($w -and $c.Connected){$c.EndConnect($a);$c.Close();exit 0}else{exit 1}" >nul 2>&1
    
    if errorlevel 1 (
        set /a DOWN_COUNT+=1
        echo [DOWN] %%W:%WORKER_PORT%
        echo        Status : OFFLINE / UNREACHABLE
        echo        Advice : Check if worker PC is on, worker-start.bat is running,
        echo                 and Windows Firewall allows inbound TCP port %WORKER_PORT%.
        echo.
    ) else (
        set /a UP_COUNT+=1
        echo [UP]   %%W:%WORKER_PORT%
        echo        Status : ONLINE and responding on RPC port %WORKER_PORT%
        echo.
    )
)

echo ============================================================================
echo  Cluster Diagnostic Summary
echo ============================================================================
echo  Total Workers Probed : %TOTAL_COUNT%
echo  Online (Active)      : %UP_COUNT%
echo  Offline (Down)       : %DOWN_COUNT%
echo.

if %UP_COUNT% EQU 0 (
    echo [RESULT] No workers available.
    echo          If you launch main-start.bat now, it will run in LOCAL-ONLY mode.
) else (
    echo [RESULT] %UP_COUNT% worker node(s) ready to accept distributed computation.
    echo          You can safely run main-start.bat on the Main PC.
)
echo ============================================================================
echo.
pause
exit /b 0
