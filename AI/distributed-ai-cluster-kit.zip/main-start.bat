@echo off
setlocal enabledelayedexpansion

:: ============================================================================
:: Distributed AI Cluster Kit - Main Server Launcher
:: Checks worker nodes via TCP 50052 (2s timeout), constructs --rpc argument,
:: and launches llama-server with graceful LOCAL-ONLY fallback.
:: Rule: Pure ASCII English, CRLF line endings, no pipelining
:: ============================================================================

:: ----------------------------------------------------------------------------
:: [EDIT THIS SECTION ONLY]
:: Enter the IP addresses of your worker PCs separated by spaces.
:: Example: set "WORKER_IPS=192.168.0.11 192.168.0.12"
:: ----------------------------------------------------------------------------
set "WORKER_IPS=192.168.0.11 192.168.0.12"
set "WORKER_PORT=50052"
set "MAIN_HOST=0.0.0.0"
set "MAIN_PORT=8080"
set "MODEL_PATH=models\Qwen2.5-7B-Instruct-Q4_K_M.gguf"
set "CONTEXT_SIZE=4096"
set "THREADS=8"
set "SEARCH_DIRS=. llama-bin bin ..\llama-bin"
:: ----------------------------------------------------------------------------

title Distributed AI Cluster - Main Server [Port %MAIN_PORT%]
echo ============================================================================
echo   Distributed AI Cluster Kit: Main Node Launcher
echo ============================================================================
echo.
echo Model Path  : %MODEL_PATH%
echo Web UI Port : %MAIN_PORT%
echo Context Size: %CONTEXT_SIZE% tokens
echo CPU Threads : %THREADS%
echo.

:: Auto-detect llama-server binary
set "SERVER_BIN="
for %%D in (%SEARCH_DIRS%) do (
    if not defined SERVER_BIN (
        if exist "%%~D\llama-server.exe" set "SERVER_BIN=%%~D\llama-server.exe"
    )
    if not defined SERVER_BIN (
        if exist "%%~D\server.exe" set "SERVER_BIN=%%~D\server.exe"
    )
)
if not defined SERVER_BIN (
    where llama-server.exe >nul 2>&1
    if not errorlevel 1 set "SERVER_BIN=llama-server.exe"
)
if not defined SERVER_BIN (
    where server.exe >nul 2>&1
    if not errorlevel 1 set "SERVER_BIN=server.exe"
)

if not defined SERVER_BIN goto :SERVER_BIN_NOT_FOUND

:: Verify model existence
if not exist "%MODEL_PATH%" goto :MODEL_NOT_FOUND

echo ============================================================================
echo [STEP 1/2] Probing Worker Nodes (TCP %WORKER_PORT%, 2s timeout per node)...
echo ============================================================================

set "RPC_LIST="
set /a ALIVE_COUNT=0
set /a TOTAL_COUNT=0

for %%W in (%WORKER_IPS%) do (
    set /a TOTAL_COUNT+=1
    set "CURRENT_IP=%%W"
    
    :: Probe TCP port using PowerShell with strict 2-second timeout
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$c=New-Object Net.Sockets.TcpClient;$a=$c.BeginConnect('%%W',%WORKER_PORT%,$null,$null);$w=$a.AsyncWaitHandle.WaitOne(2000,$false);if($w -and $c.Connected){$c.EndConnect($a);$c.Close();exit 0}else{exit 1}" >nul 2>&1
    
    if errorlevel 1 (
        echo  [-] %%W:%WORKER_PORT% --^> [DOWN] (Skipped)
    ) else (
        echo  [+] %%W:%WORKER_PORT% --^> [UP] (Active)
        set /a ALIVE_COUNT+=1
        if defined RPC_LIST (
            set "RPC_LIST=!RPC_LIST!,%%W:%WORKER_PORT%"
        ) else (
            set "RPC_LIST=%%W:%WORKER_PORT%"
        )
    )
)

echo.
echo ============================================================================
echo [STEP 2/2] Cluster Health Summary: %ALIVE_COUNT% of %TOTAL_COUNT% workers online
echo ============================================================================

if %ALIVE_COUNT% EQU 0 (
    echo.
    echo [WARNING] No worker nodes responded on port %WORKER_PORT%.
    echo [NOTICE]  Starting in LOCAL-ONLY mode on Main PC.
    echo           Inference will run entirely on the Main PC CPU.
    echo           (Slower, but fully functional. No workers required.)
    echo.
    set "CLUSTER_ARGS="
) else (
    echo.
    echo [SUCCESS] Active RPC Cluster Nodes: %RPC_LIST%
    echo [IMPORTANT NOTICE]
    echo  The RPC worker list is fixed at server startup.
    echo  If any worker node powers down or disconnects during execution,
    echo  you MUST restart main-start.bat to re-negotiate cluster workers.
    echo.
    set "CLUSTER_ARGS=--rpc !RPC_LIST!"
)

echo ============================================================================
echo [STATUS] Launching llama-server...
echo          Access Web UI at: http://localhost:%MAIN_PORT%
echo          Press Ctrl+C to stop the cluster.
echo ============================================================================
echo.

"%SERVER_BIN%" -m "%MODEL_PATH%" --host %MAIN_HOST% --port %MAIN_PORT% -c %CONTEXT_SIZE% -t %THREADS% %CLUSTER_ARGS%
set "EXIT_CODE=%errorlevel%"

echo.
echo [INFO] llama-server process terminated with exit code: %EXIT_CODE%
pause
exit /b %EXIT_CODE%

:SERVER_BIN_NOT_FOUND
echo.
echo [ERROR] Could not find llama-server binary!
echo Searched names: llama-server.exe, server.exe
echo Searched folders: %SEARCH_DIRS%
echo.
echo How to fix:
echo 1. Run setup-llamacpp.bat first to download the required binaries.
echo 2. Or place llama-server.exe into this folder or llama-bin\ folder.
echo.
pause
exit /b 1

:MODEL_NOT_FOUND
echo.
echo [ERROR] Model file not found at: %MODEL_PATH%
echo.
echo How to fix:
echo 1. Run setup-llamacpp.bat and select 'Y' to download the default model.
echo 2. Or place your own .gguf model in models\ and update MODEL_PATH in main-start.bat.
echo.
pause
exit /b 1
