@echo off
setlocal enabledelayedexpansion

:: ============================================================================
:: Distributed AI Cluster Kit - Setup llama.cpp
:: Downloads and extracts the latest llama.cpp CPU binary release and default model
:: Rule: Pure ASCII English, CRLF line endings, no pipelining
:: ============================================================================

:: ----------------------------------------------------------------------------
:: [EDIT THIS SECTION ONLY]
:: ----------------------------------------------------------------------------
set "LLAMA_VERSION=b4832"
set "DOWNLOAD_DIR=llama-bin"
set "MODEL_DIR=models"
set "MODEL_NAME=Qwen2.5-7B-Instruct-Q4_K_M.gguf"
set "MODEL_URL=https://huggingface.co/Qwen/Qwen2.5-7B-Instruct-GGUF/resolve/main/qwen2.5-7b-instruct-q4_k_m.gguf"
:: ----------------------------------------------------------------------------

title Distributed AI Cluster - llama.cpp Setup
echo ============================================================================
echo   Distributed AI Cluster Kit: llama.cpp Setup & Initial Download
echo ============================================================================
echo.
echo Target Version: %LLAMA_VERSION%
echo Output Folder : %DOWNLOAD_DIR%
echo Default Model : %MODEL_NAME%
echo.

:: Check for curl
where curl >nul 2>&1
if errorlevel 1 goto :NO_CURL

:: Check for tar or powershell
where tar >nul 2>&1
if errorlevel 1 goto :USE_POWERSHELL_EXTRACT

:: Create directories
if not exist "%DOWNLOAD_DIR%" mkdir "%DOWNLOAD_DIR%"
if not exist "%MODEL_DIR%" mkdir "%MODEL_DIR%"

set "ZIP_NAME=llama-%LLAMA_VERSION%-bin-win-cpu-x64.zip"
set "ZIP_URL=https://github.com/ggerganov/llama.cpp/releases/download/%LLAMA_VERSION%/%ZIP_NAME%"

echo [*] Downloading llama.cpp CPU release (%LLAMA_VERSION%)...
echo     URL: %ZIP_URL%
curl -L -f --retry 3 --progress-bar "%ZIP_URL%" -o "%DOWNLOAD_DIR%\%ZIP_NAME%"
if errorlevel 1 goto :DOWNLOAD_FAILED

echo [*] Extracting %ZIP_NAME% using tar...
tar -xf "%DOWNLOAD_DIR%\%ZIP_NAME%" -C "%DOWNLOAD_DIR%"
if errorlevel 1 goto :USE_POWERSHELL_EXTRACT
goto :EXTRACT_SUCCESS

:USE_POWERSHELL_EXTRACT
echo [*] Extracting with PowerShell Expand-Archive...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Path '%DOWNLOAD_DIR%\%ZIP_NAME%' -DestinationPath '%DOWNLOAD_DIR%' -Force"
if errorlevel 1 goto :EXTRACT_FAILED

:EXTRACT_SUCCESS
echo.
echo [OK] llama.cpp CPU binaries successfully extracted to: %DOWNLOAD_DIR%
echo.

:: Ask user if they want to download the recommended model now
echo ----------------------------------------------------------------------------
echo Optional Step: Download Default Model (%MODEL_NAME%) ~ 4.68 GB
echo ----------------------------------------------------------------------------
if exist "%MODEL_DIR%\%MODEL_NAME%" goto :MODEL_EXISTS

set /p DOWNLOAD_MODEL_CHOICE="Do you want to download %MODEL_NAME% now? (Y/N): "
if /i "%DOWNLOAD_MODEL_CHOICE%"=="Y" goto :DO_DOWNLOAD_MODEL
if /i "%DOWNLOAD_MODEL_CHOICE%"=="YES" goto :DO_DOWNLOAD_MODEL

echo [INFO] Skipping model download. Place your .gguf model in %MODEL_DIR%\ folder later.
goto :FINISHED

:DO_DOWNLOAD_MODEL
echo [*] Downloading model from HuggingFace to %MODEL_DIR%\%MODEL_NAME%...
echo     This may take a few minutes depending on your internet connection.
curl -L -f --retry 5 --progress-bar "%MODEL_URL%" -o "%MODEL_DIR%\%MODEL_NAME%"
if errorlevel 1 goto :MODEL_DOWNLOAD_FAILED
echo [OK] Model downloaded successfully: %MODEL_DIR%\%MODEL_NAME%
goto :FINISHED

:MODEL_EXISTS
echo [INFO] Model %MODEL_NAME% already exists in %MODEL_DIR%\. Skipping download.
goto :FINISHED

:NO_CURL
echo.
echo [ERROR] curl is not found on your system.
echo Windows 10 (build 17063 and later) or Windows 11 includes curl by default.
echo Please install curl or download the binaries manually from GitHub:
echo https://github.com/ggerganov/llama.cpp/releases
pause
exit /b 1

:DOWNLOAD_FAILED
echo.
echo [ERROR] Failed to download llama.cpp archive from GitHub.
echo Please check your internet connection or download %ZIP_URL% manually.
pause
exit /b 1

:EXTRACT_FAILED
echo.
echo [ERROR] Failed to extract the downloaded zip file.
echo Please verify if %DOWNLOAD_DIR%\%ZIP_NAME% is a valid archive.
pause
exit /b 1

:MODEL_DOWNLOAD_FAILED
echo.
echo [WARNING] Model download was interrupted or failed.
echo You can re-run this script later or download any GGUF model manually.
echo Place the .gguf file inside the "%MODEL_DIR%" folder.
pause
exit /b 1

:FINISHED
echo.
echo ============================================================================
echo [SUCCESS] Setup completed!
echo.
echo Next steps:
echo 1. On Worker PCs: copy this kit and run worker-start.bat
echo 2. On Main PC   : run main-start.bat
echo ============================================================================
echo.
pause
exit /b 0
