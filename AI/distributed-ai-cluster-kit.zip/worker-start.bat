@echo off
setlocal enabledelayedexpansion

:: ============================================================================
:: Distributed AI Cluster Kit - Worker Node Launcher
:: Runs ggml-rpc-server on port 50052 to contribute compute to the cluster
:: Rule: Pure ASCII English, CRLF line endings, no pipelining
:: ============================================================================

:: ----------------------------------------------------------------------------
:: [EDIT THIS SECTION ONLY]
:: ----------------------------------------------------------------------------
set "RPC_HOST=0.0.0.0"
set "RPC_PORT=50052"
set "SEARCH_DIRS=. llama-bin bin ..\llama-bin"
:: ----------------------------------------------------------------------------

title Distributed AI Cluster - Worker Node [Port %RPC_PORT%]
echo ============================================================================
echo   Distributed AI Cluster Kit: Worker Node Launcher
echo ============================================================================
echo.
echo Host Binding: %RPC_HOST%
echo RPC Port    : %RPC_PORT%
echo.

:: Auto-detect RPC server binary (checks new and legacy names)
set "SERVER_BIN="

:: Check candidates
for %%D in (%SEARCH_DIRS%) do (
    if not defined SERVER_BIN (
        if exist "%%~D\rpc-server.exe" set "SERVER_BIN=%%~D\rpc-server.exe"
    )
    if not defined SERVER_BIN (
        if exist "%%~D\ggml-rpc-server.exe" set "SERVER_BIN=%%~D\ggml-rpc-server.exe"
    )
    if not defined SERVER_BIN (
        if exist "%%~D\llama-rpc-server.exe" set "SERVER_BIN=%%~D\llama-rpc-server.exe"
    )
)

:: If still not found, check PATH
if not defined SERVER_BIN (
    where rpc-server.exe >nul 2>&1
    if not errorlevel 1 set "SERVER_BIN=rpc-server.exe"
)
if not defined SERVER_BIN (
    where ggml-rpc-server.exe >nul 2>&1
    if not errorlevel 1 set "SERVER_BIN=ggml-rpc-server.exe"
)

if not defined SERVER_BIN goto :BINARY_NOT_FOUND

echo [OK] Detected RPC Server binary: %SERVER_BIN%
echo.
echo ============================================================================
echo [STATUS] Starting worker node. Keep this terminal window open!
echo          Main PC will connect to this worker on port %RPC_PORT%.
echo          Press Ctrl+C to stop the worker node.
echo ============================================================================
echo.

"%SERVER_BIN%" -H %RPC_HOST% -p %RPC_PORT%
set "EXIT_CODE=%errorlevel%"

echo.
echo [INFO] Worker process stopped with exit code: %EXIT_CODE%
pause
exit /b %EXIT_CODE%

:BINARY_NOT_FOUND
echo.
echo [ERROR] Could not find ggml-rpc-server binary!
echo Searched names: rpc-server.exe, ggml-rpc-server.exe, llama-rpc-server.exe
echo Searched folders: %SEARCH_DIRS%
echo.
echo How to fix:
echo 1. Run setup-llamacpp.bat first to download the required binaries.
echo 2. Or copy rpc-server.exe into this folder or llama-bin\ folder.
echo 3. Check that Windows Defender did not quarantine the file.
echo.
pause
exit /b 1
